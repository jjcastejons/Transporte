using System;

namespace Asterisk.NET.Manager
{
	public enum AsteriskVersion
	{
		ASTERISK_1_0 = 10,
		ASTERISK_1_2 = 12,
		ASTERISK_1_4 = 14,
		ASTERISK_1_6 = 16
	}
}
