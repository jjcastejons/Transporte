﻿using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("Asterisk.NET")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("X893, http://akb77.com/g")]
[assembly: AssemblyProduct("Asterisk.NET")]
[assembly: AssemblyCopyright("Copyright © 2005-2009")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]
[assembly: Guid("abe98502-ea83-4b04-98c3-ffe3eabe06b0")]
[assembly: AssemblyVersion("1.6.3.1")]
[assembly: AssemblyFileVersion("1.6.3.1")]

// Setting ComVisible to false makes the types in this assembly not visible 
// to COM components.  If you need to access a type in this assembly from 
// COM, set the ComVisible attribute to true on that type.
[assembly: ComVisible(false)]
